package TestCases;

import org.testng.annotations.Test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


public class extentListenerRun {
	WebDriver driver;
	@BeforeMethod
	public void launchFb() {

		driver = new ChromeDriver();

		driver.get("https://www.facebook.com");
		Assert.assertEquals(driver.getTitle(), "Facebook – log in or sign up");
		}

	@Test
	public void fblogin() {
		WebElement user = driver.findElement(By.id("email"));
		Assert.assertTrue(user.isDisplayed());
		user.sendKeys("user1");
		WebElement pwd = driver.findElement(By.id("pass"));
		Assert.assertTrue(pwd.isDisplayed());
		pwd.sendKeys("test");
		System.out.println("Running Facebook login test...");
		

		Assert.assertEquals(10, 10);
	}

	@Test
	public void fbforgetpassword() {
		
		System.out.println("Running Facebook forgot password test...");

		Assert.assertEquals(101, 10);
	}

	@AfterMethod
	public void closeBrowser() {
		driver.quit();
	}
}
