package TestScript;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ReadDetails {
	public static String getLocatorsProperties(String Key) {
		String value=null;
		try {
			FileInputStream fis=new FileInputStream("\\src\\test\\java\\Repository\\locators.properties");
			Properties properties=new Properties();
			try {
				properties.load(fis);
			} catch (IOException e) {
				e.printStackTrace();
			}
			value=properties.getProperty(Key);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return value;
	}
	public static WebElement getElementRef(String key1,WebDriver driver) {
			WebElement ele=null;;
			String value=getLocatorsProperties(key1);
			String[]info=value.split(":");
			switch(info[0]) {
			case "name":
				ele=driver.findElement(By.name(info[1]));
				break;
			case "id":
				ele=driver.findElement(By.id(info[1]));
				break;
			case "xpath":
				ele=driver.findElement(By.xpath(info[1]));
				break;
			case "className":
				ele=driver.findElement(By.className(info[1]));
				break;
			case "linktext":
				ele=driver.findElement(By.linkText(info[0]));
				break;
				default:
					System.out.println("Invalid constructor");
				
			
			}
			return ele;
			
	}

}
